const C="golden-tap-v6",F=["./","index.html","style.css","game.js","manifest.json","assets/icon.svg","assets/icon-192.png","assets/icon-512.png","assets/world-tropical.svg","assets/world-coral.svg","assets/world-volcano.svg","assets/world-moon.svg","assets/world-mushroom.svg"];
self.addEventListener("install",e=>{e.waitUntil(caches.open(C).then(c=>c.addAll(F)).then(()=>self.skipWaiting()))});
self.addEventListener("activate",e=>{e.waitUntil(caches.keys().then(k=>Promise.all(k.filter(x=>x!==C).map(x=>caches.delete(x)))).then(()=>self.clients.claim()))});
self.addEventListener("fetch",e=>{if(e.request.method!=="GET")return;e.respondWith(fetch(e.request).then(r=>{const c=r.clone();caches.open(C).then(x=>x.put(e.request,c));return r}).catch(()=>caches.match(e.request)))});
