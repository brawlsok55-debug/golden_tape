(()=>{"use strict";
const $=i=>document.getElementById(i),KEY="goldenTap2",OLD="goldenTap10";
const IC={gloves:'<path d="M9 30V14a3 3 0 016 0v8V9a3 3 0 016 0v13V11a3 3 0 016 0v11V16a3 3 0 016 0v14c0 8-5 12-12 12S9 38 9 30z" fill="#ffd54a" stroke="#a8651a" stroke-width="2.5"/>',
pick:'<path d="M8 14Q24 2 40 14" stroke="#c9d3da" stroke-width="5" fill="none" stroke-linecap="round"/><path d="M24 8L26 42" stroke="#a65d28" stroke-width="5" stroke-linecap="round"/><circle cx="24" cy="8" r="3.5" fill="#ffd54a"/>',
parrot:'<ellipse cx="24" cy="28" rx="11" ry="14" fill="#e53935"/><circle cx="24" cy="14" r="9" fill="#e53935"/><path d="M28 14l9 3-8 4z" fill="#ffd54a"/><circle cx="22" cy="12" r="2.4" fill="#fff"/><path d="M14 30q-8 8 0 14M34 28q8 4 4 14" stroke="#1e88e5" stroke-width="5" fill="none" stroke-linecap="round"/>',
magnet:'<path d="M10 10v14a14 14 0 0028 0V10" stroke="#e53935" stroke-width="9" fill="none"/><path d="M5.5 6h9v8h-9zM33.5 6h9v8h-9z" fill="#eee"/>',
talisman:'<path d="M24 4l6 13 14 2-10 10 3 14-13-7-13 7 3-14L4 19l14-2z" fill="#b57cff" stroke="#ffd54a" stroke-width="2.5" stroke-linejoin="round"/><circle cx="24" cy="24" r="5" fill="#ffd54a"/>'};
const UP=[
{id:"gloves",n:"Золотые перчатки",d:"+1 монета за нажатие за уровень",b:600,g:1.35},
{id:"pick",n:"Королевская кирка",d:"+5 монет за нажатие за уровень",b:4400,g:1.4},
{id:"parrot",n:"Попугай-сокровищник",d:"+2 монеты в секунду за уровень",b:2400,g:1.38},
{id:"magnet",n:"Магнит для монет",d:"+10 монет в секунду за уровень",b:18000,g:1.42},
{id:"talisman",n:"Золотой талисман",d:"+10% ко всему доходу за уровень",b:50000,g:1.7}];
const WD=[{id:"tropical",n:"Tropical Paradise",d:"Пальмы, водопады и бирюзовый океан",p:0},
{id:"coral",n:"Coral Bay",d:"Коралловая бухта, рыбки и пузырьки",p:100000},
{id:"volcano",n:"Golden Volcano",d:"Лава, пепел и золотые жилы",p:2500000},
{id:"moon",n:"Moon Lagoon",d:"Лунная лагуна и светящиеся кристаллы",p:25000000},{id:"mushroom",n:"Mushroom Kingdom",d:"Гигантские светящиеся грибы и волшебные огни",p:100000000}];
const AMB={tropical:["#fff8b0",5],coral:["#ffffff88",9],volcano:["#ffa23a",4],moon:["#bfe8ff",4],mushroom:["#b6ff9e",6]};
let s={v:3,coins:0,total:0,taps:0,xp:0,level:1,own:{},worlds:["tropical"],world:"tropical",sfx:true,mus:true,ts:Date.now(),bonus:0,opened:0,rare:0,titles:["novice"],title:"novice",av:0,nick:"Игрок"+(1000+Math.floor(Math.random()*9000)),q:{day:"",base:{taps:0,opened:0,bought:0},claimed:{}}};
try{const r=localStorage.getItem(KEY);if(r)s={...s,...JSON.parse(r)};else{const o=JSON.parse(localStorage.getItem(OLD)||"null");
 if(o){s.coins=+o.coins||0;s.total=+o.total||0;s.sfx=o.sound!==false;for(const k in(o.owned||{}))if(UP.some(u=>u.id===k))s.own[k]=o.owned[k];
 const m={"Тропический рай":"tropical","Коралловая бухта":"coral","Золотой вулкан":"volcano","Лунная лагуна":"moon"};
 (o.unlocked||[]).forEach(n=>m[n]&&!s.worlds.includes(m[n])&&s.worlds.push(m[n]));s.world=m[o.world]||"tropical"}}}catch(e){}
if(!s.worlds.includes(s.world))s.world="tropical";
if(!(s.v>=3)){s.opened=Math.max(+s.opened||0,Math.floor((s.taps||0)/25));s.v=3} /* миграция 2.0 -> 3 */
if(!Array.isArray(s.titles)||!s.titles.includes("novice"))s.titles=["novice",...(Array.isArray(s.titles)?s.titles:[])];
s.q=s.q&&s.q.base&&s.q.claimed?s.q:{day:"",base:{taps:0,opened:0,bought:0},claimed:{}};
s.skins=s.skins&&Array.isArray(s.skins.own)?s.skins:{own:[],eq:""};s.v=4;s.cu=s.cu&&typeof s.cu==="object"?s.cu:{};s.mine=Object.assign({l:1,st:0,t:Date.now()},s.mine);s.hunt=Object.assign({end:0,i:-1,res:null},s.hunt);s.sea=Object.assign({end:0,i:-1,res:null,ship:1},s.sea);
const fmt=n=>Math.floor(n).toLocaleString("ru-RU"),lv=id=>s.own[id]||0,cost=u=>Math.floor(u.b*u.g**lv(u.id));
const mult=()=>1+.1*lv("talisman"),tapPow=()=>Math.round((1+lv("gloves")+5*lv("pick"))*mult()*cf("tap"))+Math.round(cl(s.world,"tap")*PW[s.world]),auto=()=>(2*lv("parrot")+10*lv("magnet"))*mult();
const need=l=>Math.floor(50*l**1.5),bought=()=>Object.values(s.own).reduce((a,b)=>a+b,0)+Object.values(s.cu).reduce((a,w)=>a+Object.values(w).reduce((x,y)=>x+y,0),0)+(s.mine.l-1)+(s.sea.ship-1);
let dirty=false;function save(){try{s.ts=Date.now();localStorage.setItem(KEY,JSON.stringify(s))}catch(e){}}
function toast(t){const e=$("toast");e.textContent=t;e.classList.add("on");clearTimeout(toast.t);toast.t=setTimeout(()=>e.classList.remove("on"),1800)}
/* ---------- AUDIO ---------- */
let AC=null,out=null,musT=null,step=0;
function audio(){ // вызывать только из жеста пользователя (или после него)
 try{if(!AC){AC=new(window.AudioContext||window.webkitAudioContext)();out=AC.createGain();out.connect(AC.destination)}
 if(AC.state!=="running")AC.resume().then(startMus).catch(()=>{});else startMus()}catch(e){}return AC&&AC.state!=="closed"}
function tone(f,d,type="sine",v=.15,at=0,to=0){if(!AC)return;const t=AC.currentTime+at,o=AC.createOscillator(),g=AC.createGain();o.type=type;o.frequency.setValueAtTime(f,t);if(to)o.frequency.exponentialRampToValueAtTime(to,t+d);
 g.gain.setValueAtTime(0,t);g.gain.linearRampToValueAtTime(v,t+.01);g.gain.exponentialRampToValueAtTime(.0008,t+d);o.connect(g);g.connect(out);o.start(t);o.stop(t+d+.02)}
const SND={tap:()=>{tone(180,.09,"triangle",.25,0,90);tone(1200+Math.random()*300,.1,"sine",.08,.02)},
coin:()=>{tone(1318,.12,"square",.05);tone(1760,.25,"square",.05,.07)},
open:()=>{[392,523,659,784,1047].forEach((f,i)=>tone(f,.35,"triangle",.14,i*.07));tone(2093,.6,"sine",.06,.3)},
buy:()=>{tone(784,.1,"square",.07);tone(1046,.12,"square",.07,.09);tone(1568,.4,"triangle",.12,.18)},
world:()=>{[262,330,392,523,659].forEach((f,i)=>{tone(f,.7,"triangle",.1,i*.09);tone(f*2,.5,"sine",.05,i*.09)})},
ui:()=>tone(520,.07,"sine",.08,0,700),
appear:()=>{tone(880,.18,"sine",.09,0,1400);tone(1760,.2,"sine",.05,.12)},
silver:()=>{tone(1568,.25,"triangle",.1);tone(2093,.4,"sine",.08,.1);tone(2637,.5,"sine",.05,.2)},
gold:()=>{[523,659,784,1047,1319,1568].forEach((f,i)=>tone(f,.4,"square",.05,i*.06));tone(2093,.8,"sine",.08,.35)},
mystic:()=>{tone(110,1.2,"sawtooth",.08,0,330);[392,466,587,784,932,1175].forEach((f,i)=>tone(f,.9,"sine",.09,i*.1));tone(3136,1,"sine",.05,.5)}};
function sfx(n){if(s.sfx&&AC&&AC.state!=="closed")SND[n]()}
const SCALE=[0,3,7,10,12,10,7,3],BASE={tropical:262,coral:294,volcano:220,moon:247,mushroom:233};
function startMus(){if(!s.mus||musT||!AC||AC.state!=="running")return;musT=setInterval(()=>{if(!s.mus||AC.state!=="running")return;const f=BASE[s.world]*2**(SCALE[step%8]/12);tone(f,.9,"triangle",.035);if(step%4===0)tone(f/2,1.6,"sine",.05);step++},420)}
function stopMus(){clearInterval(musT);musT=null}
["pointerdown","touchend","keydown"].forEach(e=>addEventListener(e,audio,{capture:true,passive:true}));
document.addEventListener("visibilitychange",()=>{if(document.hidden){stopMus();save()}else if(AC)AC.resume().then(startMus).catch(()=>{})});
addEventListener("pagehide",()=>{save()});addEventListener("pageshow",()=>{if(AC)AC.resume().catch(()=>{})});
/* ---------- UI ---------- */
function hud(){hud2();$("coins").textContent=fmt(s.coins);$("lvl").textContent=s.level;$("xp").style.width=Math.min(100,s.xp/need(s.level)*100)+"%";
 $("power").textContent=fmt(tapPow());$("autoStat").textContent=fmt(auto());$("total").textContent=fmt(s.total);$("taps").textContent=s.taps;$("bought").textContent=bought();
 $("stTotal").textContent=fmt(s.total);$("stTaps").textContent=s.taps;$("stBought").textContent=bought();
 $("bonusBar").style.width=s.bonus/25*100+"%";$("bonusTxt").textContent="Бонус-сундук: "+s.bonus+" / 25";
 document.querySelectorAll("[data-u]").forEach(b=>{const u=UP.find(x=>x.id===b.dataset.u),c=cost(u);b.disabled=s.coins<c;b.textContent=fmt(c)+" 🪙";b.previousElementSibling.querySelector("em").textContent="Уровень "+lv(u.id)});
 document.querySelectorAll("[data-w]").forEach(b=>{const w=WD.find(x=>x.id===b.dataset.w),own=s.worlds.includes(w.id);b.disabled=!own&&s.coins<w.p;b.className="buy"+(own?" alt":"");b.textContent=s.world===w.id?"Выбран":own?"Выбрать":fmt(w.p)+" 🪙";b.disabled=b.disabled||s.world===w.id;b.previousElementSibling.querySelector("em").textContent=s.world===w.id?"★ Текущий мир":own?"✓ Открыт":"🔒 Закрыт · "+fmt(w.p)+" 🪙";b.parentElement.classList.toggle("cur",s.world===w.id);b.parentElement.classList.toggle("locked",!own)})}
let q=0;const upd=()=>{if(!q)q=requestAnimationFrame(()=>{q=0;hud()})};
const T=[{id:"novice",n:"Новичок",d:"Стартовый титул",ok:()=>true},
{id:"seeker",n:"Искатель золота",d:"Открыть 500 сундуков",ok:()=>chests()>=500},
{id:"magnate",n:"Золотой магнат",d:"Иметь на балансе 5 000 000 монет",ok:()=>s.coins>=5e6},
{id:"lord",n:"Повелитель сокровищ",d:"Купить 120 улучшений",ok:()=>bought()>=120},
{id:"legend",n:"Легенда островов",d:"Открыть все 5 миров",ok:()=>s.worlds.length>=WD.length},
{id:"emperor",n:"Император золота",d:"Иметь на балансе 1 000 000 000 монет",ok:()=>s.coins>=1e9}];
const Q=[{id:"bal",n:"Золотой баланс",d:"Иметь на балансе одновременно 100 000 монет (считается текущий баланс)",t:1e5,r:12000,v:()=>s.coins},
{id:"chest",n:"Великий клад",d:"Открыть 50 000 обычных сундуков",t:5e4,r:150000,v:()=>s.opened-s.q.base.opened},
{id:"tap",n:"Активный искатель",d:"Сделать 2 000 нажатий на сундук",t:2e3,r:5000,v:()=>s.taps-s.q.base.taps},
{id:"buy",n:"Покупатель",d:"Купить 5 улучшений",t:5,r:8000,v:()=>bought()-s.q.base.bought}];
const AV=["👑","🦜","🏴‍☠️","⚓","🌴","🐚"];let cur="home";
const chests=()=>s.opened+s.rare,tname=id=>T.find(t=>t.id===id).n;
function hud2(){chk();if(cur==="shop"){updCU();updSk()}if(cur==="act")updAct();if(cur==="quests")updQ();if(cur==="profile")updPf()}
function dayKey(){const d=new Date();return d.getFullYear()+"-"+(d.getMonth()+1)+"-"+d.getDate()}
function ensureDay(){const k=dayKey();if(s.q.day!==k){s.q={day:k,base:{taps:s.taps,opened:s.opened,bought:bought()},claimed:{}};save();return true}return false}
function chk(){let n=false;T.forEach(t=>{if(!s.titles.includes(t.id)&&t.ok()){s.titles.push(t.id);toast("Новый титул: "+t.n+"!");n=true}});if(n){save();sfx("open")}}
function updQ(){const left=new Date(new Date().setHours(24,0,0,0))-Date.now(),h=Math.floor(left/36e5),m=Math.floor(left/6e4)%60;$("qTimer").textContent="Обновление через "+h+" ч "+m+" мин";
 Q.forEach(x=>{const v=Math.min(x.v(),x.t),cl=!!s.q.claimed[x.id],ok=x.v()>=x.t,e=$("q_"+x.id);e.querySelector(".bar i").style.width=v/x.t*100+"%";e.querySelector("em").textContent=fmt(v)+" / "+fmt(x.t);
 const b=e.querySelector("button");b.disabled=cl||!ok;b.textContent=cl?"✓ Получено":ok?"Забрать награду":"В процессе";e.classList.toggle("done",cl)})}
function updPf(){$("avatar").textContent=AV[s.av%AV.length];$("pfTitle").textContent="Титул: "+tname(s.title);$("pfLvl").textContent="Уровень "+s.level;
 const st=[["БАЛАНС",fmt(s.coins)],["ВСЕГО ЗАРАБОТАНО",fmt(s.total)],["ОТКРЫТО СУНДУКОВ",chests()],["НАЖАТИЙ",s.taps],["КУПЛЕНО УЛУЧШЕНИЙ",bought()],["ОТКРЫТО МИРОВ",s.worlds.length+" / "+WD.length],["УРОВЕНЬ ШАХТЫ",s.mine.l],["УРОВЕНЬ КОРАБЛЯ",s.sea.ship],["СКИНОВ",s.skins.own.length+" / "+SK.length],["НАДЕТЫЙ СКИН",(SK.find(x=>x.id===s.skins.eq)||{n:"Стандартный"}).n],["ОЧКИ РЕЙТИНГА",fmt(ratingPts())],["МЕСТО В РЕЙТИНГЕ","—"]];
 $("pfStats").innerHTML=st.map(a=>`<div><small>${a[0]}</small><b>${a[1]}</b></div>`).join("");
 T.forEach(t=>{const e=$("t_"+t.id),own=s.titles.includes(t.id),b=e.querySelector("button");e.classList.toggle("lk",!own);e.classList.toggle("sel",s.title===t.id);b.disabled=!own||s.title===t.id;b.textContent=s.title===t.id?"Выбран":own?"Выбрать":"🔒"})}
function build(){
 $("qList").innerHTML=Q.map(x=>`<div class="item" id="q_${x.id}"><div class="inf"><b>${x.n}</b><small>${x.d}</small><div class="bar"><i></i></div><em></em> <small>Награда: ${fmt(x.r)} 🪙</small></div><button class="buy" data-q="${x.id}"></button></div>`).join("");
 $("titleList").innerHTML=T.map(t=>`<div class="item" id="t_${t.id}"><div class="inf"><b>${t.n}</b><small>${t.d}</small></div><button class="buy alt" data-t="${t.id}"></button></div>`).join("");$("upList").innerHTML=UP.map(u=>`<div class="item"><div class="ico"><svg viewBox="0 0 48 48">${IC[u.id]}</svg></div><div class="inf"><b>${u.n}</b><small>${u.d}</small><em></em></div><button class="buy" data-u="${u.id}"></button></div>`).join("");
 $("worldList").innerHTML=WD.map(w=>`<div class="item"><div class="wprev" style="background-image:url(assets/world-${w.id}.svg)"></div><div class="inf"><b>${w.n}</b><small>${w.d}</small><em></em></div><button class="buy" data-w="${w.id}"></button></div>`).join("")}
let bgOn="bgA";function setWorld(first){const id=s.world,nxt=bgOn==="bgA"?"bgB":"bgA";$(nxt).style.backgroundImage=`url(assets/world-${id}.svg)`;
 if(first){$(bgOn).style.backgroundImage=`url(assets/world-${id}.svg)`}else{$(nxt).classList.add("on");$(bgOn).classList.remove("on");bgOn=nxt}
 $("app").dataset.world=id;$("wname").textContent=WD.find(w=>w.id===id).n;document.querySelector('meta[name=theme-color]').content={tropical:"#2aa9e8",coral:"#0b8fb8",volcano:"#1a0505",moon:"#070b33",mushroom:"#1a0a33"}[id];$("amb").innerHTML="";chestLook()}
function gain(n,xp){s.coins+=n;s.total+=n;addXp(xp)}
function addXp(x){s.xp+=x;while(s.xp>=need(s.level)){s.xp-=need(s.level);s.level++;toast("Новый уровень: "+s.level+"!");sfx("open")}}
/* ---------- эффекты ---------- */
function burst(x,y,n,big){const fx=$("fx");while(fx.childElementCount>70)fx.firstChild.remove();
 for(let i=0;i<n;i++){const c=document.createElement("div");c.className="coin";c.style.left=x+"px";c.style.top=y+"px";c.style.setProperty("--x",(Math.random()*2-1)*(big?150:90)+"px");c.style.setProperty("--y",-(60+Math.random()*(big?150:90))+"px");fx.append(c);setTimeout(()=>c.remove(),850)}
 for(let i=0;i<n*2;i++){const c=document.createElement("div");c.className="spark";c.style.left=x+"px";c.style.top=y+"px";const a=Math.random()*6.28,d=30+Math.random()*(big?110:60);c.style.setProperty("--x",Math.cos(a)*d+"px");c.style.setProperty("--y",Math.sin(a)*d+"px");fx.append(c);setTimeout(()=>c.remove(),600)}}
function float(x,y,t){const e=document.createElement("div");e.className="ft";e.textContent=t;e.style.left=x+"px";e.style.top=y+"px";$("fx").append(e);setTimeout(()=>e.remove(),800)}
let openT;function openLid(ms){const c=$("chest");c.classList.add("open");clearTimeout(openT);openT=setTimeout(()=>c.classList.remove("open"),ms)}
/* ---------- действия ---------- */
function tap(e){const r=$("chest").getBoundingClientRect(),x=e.clientX||r.left+r.width/2,y=e.clientY||r.top+r.height/2,p=tapPow();
 gain(p,1);s.taps++;s.bonus++;if(Math.random()<.02*cl(s.world,"extra")*PW[s.world]){const x2=p*6;gain(x2,2);float(x,y-62,"★ +"+fmt(x2))}const c=$("chest");c.classList.add("hit");setTimeout(()=>c.classList.remove("hit"),90);
 sfx("tap");sfx("coin");burst(r.left+r.width/2,r.top+r.height*.4,5);float(x,y-30,"+"+fmt(p));openLid(140);
 if(s.bonus>=25){s.bonus=0;s.opened++;const b=Math.round(p*15*(1+.2*cl(s.world,"base")*PW[s.world]));gain(b,15);sfx("open");openLid(700);burst(r.left+r.width/2,r.top+r.height*.4,16,true);toast("Сундук открыт! Бонус +"+fmt(b)+" 🪙");save()}
 else if(s.taps%20===0)save();upd()}
function buy(id){const u=UP.find(x=>x.id===id),c=cost(u);if(!u||s.coins<c)return;s.coins-=c;s.own[id]=lv(id)+1;addXp(10);sfx("buy");toast(u.n+" — уровень "+lv(id));save();hud()}
function pickWorld(id){const w=WD.find(x=>x.id===id);if(!w||s.world===id)return;
 if(!s.worlds.includes(id)){if(s.coins<w.p)return;s.coins-=w.p;s.worlds.push(id);addXp(50);sfx("world");toast("Мир открыт: "+w.n)}else sfx("ui");
 s.world=id;stopMus();setWorld();startMus();save();hud()}
function page(p){cur=p;if(p!=="home")clearRare(true);if(p==="quests")ensureDay();document.querySelectorAll(".screen").forEach(x=>x.classList.toggle("on",x.id===p));document.querySelectorAll("nav button").forEach(b=>b.classList.toggle("on",b.dataset.p===p));sfx("ui");hud()}
function sw(){$("swSfx").classList.toggle("on",s.sfx);$("swMus").classList.toggle("on",s.mus)}
/* ---------- редкие сундуки ---------- */
const RT=[{id:"silver",n:"Серебряный сундук",w:70,m:1,c:["#eef3f6","#8d9aa6"],g:"#cfe6ff",life:12},
{id:"gold",n:"Золотой сундук",w:25,m:4,c:["#fff3a6","#c98a1c"],g:"#ffd54a",life:10},
{id:"mystic",n:"Мистический сундук",w:5,m:15,c:["#d9adff","#6a2fc2"],g:"#c07bff",life:8}];
let rc=null,nextRare=Date.now()+45e3+Math.random()*45e3;
const rsvg=c=>`<svg viewBox="0 0 86 80"><ellipse cx="43" cy="74" rx="34" ry="5" fill="#0005"/><rect x="8" y="36" width="70" height="36" rx="5" fill="${c[1]}"/><path d="M8 38V30Q8 10 43 10Q78 10 78 30V38Z" fill="${c[0]}"/><rect x="8" y="34" width="70" height="6" fill="${c[0]}" opacity=".8"/><rect x="14" y="14" width="8" height="58" fill="${c[0]}" opacity=".55"/><rect x="64" y="14" width="8" height="58" fill="${c[0]}" opacity=".55"/><rect x="36" y="32" width="14" height="16" rx="3" fill="${c[0]}" stroke="#0006" stroke-width="2"/><circle cx="43" cy="39" r="2.5" fill="#0007"/><path d="M20 20Q30 14 40 16" stroke="#fff" stroke-opacity=".7" stroke-width="3" fill="none" stroke-linecap="round"/></svg>`;
function pickRare(){let r=Math.random()*100,i=0;for(let k=0;k<3;k++){if(r<RT[k].w){i=k;break}r-=RT[k].w}if(i<2&&Math.random()<.03*cl(s.world,"rare")*PW[s.world])i++;return RT[i]}
function clearRare(silent){if(!rc)return;const o=rc;rc=null;clearTimeout(o.t);if(silent)o.el.remove();else{o.el.classList.add("out");setTimeout(()=>o.el.remove(),400)}}
function spawnRare(){const t=pickRare(),e=document.createElement("button");e.className="rc";e.setAttribute("aria-label",t.n);e.style.cssText=`left:${6+Math.random()*64}%;top:${15+Math.random()*12}%;--g:${t.g};--t:${t.life}s`;e.innerHTML=rsvg(t.c)+"<i><b></b></i>";
 const o={el:e,type:t,done:false};e.addEventListener("pointerdown",ev=>{ev.preventDefault();ev.stopPropagation();openRare(o)});
 o.t=setTimeout(()=>{if(rc===o&&!o.done){clearRare(false);toast(t.n+" исчез...")}},t.life*1e3);rc=o;$("rare").append(e);sfx("appear");
 nextRare=Date.now()+t.life*1e3+(75e3+Math.random()*75e3)/(1+.08*cl(s.world,"rare")*PW[s.world])}
function openRare(o){if(o.done)return;o.done=true;clearTimeout(o.t);const t=o.type,r=Math.round((tapPow()*20+auto()*15+25)*t.m);gain(r,5*t.m);s.rare++;
 const b=o.el.getBoundingClientRect();o.el.classList.add("open");burst(b.left+b.width/2,b.top+b.height/2,t.id==="mystic"?20:t.id==="gold"?14:8,t.m>1);float(b.left+b.width/2,b.top,"+"+fmt(r));sfx(t.id);toast(t.n+": +"+fmt(r)+" 🪙");
 if(rc===o)rc=null;setTimeout(()=>o.el.remove(),500);save();hud()}
setInterval(()=>{if(Date.now()<nextRare)return;if(rc||document.hidden||cur!=="home"||$("modal").classList.contains("on")){nextRare=Date.now()+5e3;return}spawnRare()},1000);
/* ---------- события ---------- */
$("qList").addEventListener("click",e=>{const b=e.target.closest("[data-q]");if(!b)return;const x=Q.find(z=>z.id===b.dataset.q);ensureDay();
 if(!x||s.q.claimed[x.id]||x.v()<x.t)return;s.q.claimed[x.id]=1;gain(x.r,0);save();sfx("open");toast("Награда: +"+fmt(x.r)+" 🪙");hud()});
$("titleList").addEventListener("click",e=>{const b=e.target.closest("[data-t]");if(!b||!s.titles.includes(b.dataset.t))return;s.title=b.dataset.t;sfx("ui");save();hud()});
$("avatar").onclick=()=>{s.av=(s.av+1)%AV.length;sfx("ui");save();hud()};
$("nick").addEventListener("input",()=>{s.nick=$("nick").value.trim().slice(0,16)||s.nick;save()});
$("nick").addEventListener("blur",()=>{$("nick").value=s.nick});
setInterval(()=>{if(ensureDay())hud();else if(cur==="quests")updQ()},1000);
document.addEventListener("visibilitychange",()=>{if(!document.hidden){ensureDay();hud()}});
$("chest").addEventListener("pointerdown",e=>{e.preventDefault();tap(e)});
$("chest").addEventListener("keydown",e=>{if(e.key==="Enter"||e.key===" "){e.preventDefault();tap(e)}});
$("upList").addEventListener("click",e=>{const b=e.target.closest("[data-u]");b&&buy(b.dataset.u)});
$("worldList").addEventListener("click",e=>{const b=e.target.closest("[data-w]");b&&pickWorld(b.dataset.w)});
document.querySelector("nav").addEventListener("click",e=>{const b=e.target.closest("button");b&&page(b.dataset.p)});
$("gear").onclick=()=>{$("modal").classList.add("on");sfx("ui")};$("close").onclick=()=>$("modal").classList.remove("on");
$("modal").addEventListener("click",e=>{if(e.target===$("modal"))$("modal").classList.remove("on")});
$("swSfx").onclick=()=>{s.sfx=!s.sfx;audio();sw();save();sfx("ui")};
$("swMus").onclick=()=>{s.mus=!s.mus;if(s.mus){audio();startMus()}else stopMus();sw();save()};
$("reset").onclick=()=>{if(confirm("Удалить весь прогресс?")){localStorage.removeItem(KEY);localStorage.removeItem(OLD);location.reload()}};
document.addEventListener("contextmenu",e=>{if(!e.target.closest("input,textarea"))e.preventDefault()});
document.addEventListener("dragstart",e=>e.preventDefault());
/* ---------- цикл ---------- */
setInterval(()=>{const a=auto();if(a>0){gain(a*.25,a*.01);upd()}},250);
setInterval(()=>{if(document.hidden)return;const [c,n]=AMB[s.world],h=$("amb");if(h.childElementCount>n*2)return;const i=document.createElement("i"),z=3+Math.random()*7;
 i.style.cssText=`left:${Math.random()*100}%;width:${z}px;height:${z}px;background:${c};--d:${6+Math.random()*6}s;--x:${Math.random()*60-30}px;box-shadow:0 0 ${z*2}px ${c}`;h.append(i);setTimeout(()=>i.remove(),12500)},900);

/* ---------- v4: сундуки миров, шахта, экспедиции ---------- */
const PW={tropical:1,coral:1.15,volcano:1.3,moon:1.5,mushroom:1.8},WM={tropical:1,coral:3,volcano:10,moon:30,mushroom:90},
CN={tropical:"Тропический сундук",coral:"Морской сундук",volcano:"Вулканический сундук",moon:"Лунный сундук",mushroom:"Грибной сундук"},CMAX=10,
CU=[{id:"tap",n:"Сила нажатия",d:"+12% и +1 монета за нажатие за уровень",b:1200,g:1.55},{id:"base",n:"Награда сундука",d:"+20% к награде бонус-сундука за уровень",b:1800,g:1.55},{id:"extra",n:"Доп. награда",d:"+2% шанс получить ×6 монет за нажатие",b:2800,g:1.6},{id:"rare",n:"Редкие находки",d:"Редкие сундуки чаще и лучше",b:4000,g:1.6}];
const cl=(w,id)=>(s.cu[w]||{})[id]||0,cf=id=>1+.12*cl(s.world,id)*PW[s.world],ccost=u=>Math.floor(u.b*WM[s.world]*u.g**cl(s.world,u.id));
function chestLook(){const t=Object.values(s.cu[s.world]||{}).reduce((a,b)=>a+b,0),c=$("chest");c.dataset.st=t>=30?3:t>=15?2:t>=5?1:0;const k=SK.find(x=>x.id===s.skins.eq);if(k){c.dataset.skin=k.id;c.dataset.sr=k.r;c.style.setProperty("--sf",k.f);c.style.setProperty("--sk",k.c)}else{delete c.dataset.skin;delete c.dataset.sr}}
function bldCU(){$("cuList").innerHTML=CU.map(u=>`<div class="item"><div class="inf"><b>${u.n}</b><small>${u.d}</small><em id="cu_${u.id}"></em></div><button class="buy" data-c="${u.id}"></button></div>`).join("")}
function updCU(){const w=s.world,L=Object.values(s.cu[w]||{}).reduce((a,b)=>a+b,0);$("cuH").textContent=CN[w]+" · ур. "+L+" · вид "+$("chest").dataset.st+"/3";
 CU.forEach(u=>{const l=cl(w,u.id),m=l>=CMAX,c=ccost(u),b=document.querySelector(`[data-c=${u.id}]`);$("cu_"+u.id).textContent="Уровень "+l+" / "+CMAX;b.disabled=m||s.coins<c;b.textContent=m?"МАКС":fmt(c)+" 🪙"})}
function buyCU(id){const u=CU.find(x=>x.id===id),c=ccost(u);if(!u||cl(s.world,id)>=CMAX||s.coins<c)return;s.coins-=c;(s.cu[s.world]=s.cu[s.world]||{})[id]=cl(s.world,id)+1;addXp(10);sfx("buy");toast(CN[s.world]+": "+u.n+" "+cl(s.world,id));chestLook();save();hud()}
$("cuList").addEventListener("click",e=>{const b=e.target.closest("[data-c]");b&&buyCU(b.dataset.c)});
/* шахта */
const MN={rate:l=>Math.round(3*l**1.5),cap:l=>Math.round(3*l**1.5)*7200,up:l=>Math.floor(10000*1.9**(l-1)),max:20};
function mineTick(){const m=s.mine,n=Date.now(),r=MN.rate(m.l),c=MN.cap(m.l),dt=Math.max(0,Math.min((n-m.t)/1000,7200));m.st=Math.min(c,m.st+r*dt);m.t=n}
function mineCollect(){mineTick();const g=Math.floor(s.mine.st);if(g<1)return;s.mine.st=0;gain(g,2);sfx("open");toast("Шахта: +"+fmt(g)+" 🪙");save();hud()}
function mineUp(){const m=s.mine,c=MN.up(m.l);if(m.l>=MN.max||s.coins<c)return;mineTick();s.coins-=c;m.l++;addXp(20);sfx("buy");toast("Шахта: уровень "+m.l);save();hud()}
/* экспедиции */
const EX={hunt:{n:"🗺 Поиск сокровищ",ok:.85,v:["Монеты","Старинный клад","Реликвия"],s:[{n:"Пляжный тайник",c:4000,t:30,r:[8000,18000]},{n:"Старая пещера",c:40000,t:120,r:[100000,220000]},{n:"Затерянный храм",c:300000,t:420,r:[900000,2000000]}]},
sea:{n:"⛵ Морские экспедиции",ok:.9,v:["Груз","Сундук пиратов","Морская жемчужина"],s:[{n:"Остров Черепа",c:10000,t:60,r:[20000,44000]},{n:"Риф Сирен",c:100000,t:240,r:[240000,520000]},{n:"Остров Бурь",c:800000,t:600,r:[2000000,4400000]}]}};
const shipM=()=>1+.25*(s.sea.ship-1),shipT=()=>1-.05*(s.sea.ship-1),shipC=()=>Math.floor(60000*2.2**(s.sea.ship-1));
function send(k,i){const e=s[k],X=EX[k],z=X.s[i];if(!z||e.end||s.coins<z.c)return;s.coins-=z.c;const sea=k==="sea",m=sea?shipM():1;let res;
 if(Math.random()>X.ok)res={c:Math.round(z.c*.3),n:"Неудача — вернулось немного"};else{const v=z.r[0]+Math.random()*(z.r[1]-z.r[0]),x=Math.random(),y=x<.6?0:x<.9?1:2;res={c:Math.round(v*m*[1,2,4][y]),n:X.v[y],rare:y==2}}
 e.i=i;e.res=res;e.end=Date.now()+z.t*1000*(sea?shipT():1);sfx("ui");toast("Отправлено: "+z.n);save();hud()}
function claim(k){const e=s[k];if(!e.end||!e.res||Date.now()<e.end)return;const r=e.res;e.end=0;e.i=-1;e.res=null;gain(r.c,5);sfx(r.rare?"mystic":"open");toast(r.n+": +"+fmt(r.c)+" 🪙");save();hud()}
function shipUp(){const c=shipC();if(s.sea.ship>=10||s.coins<c)return;s.coins-=c;s.sea.ship++;addXp(20);sfx("buy");toast("Корабль: уровень "+s.sea.ship);save();hud()}
const mmss=ms=>{ms=Math.max(0,Math.ceil(ms/1000));return Math.floor(ms/60)+":"+String(ms%60).padStart(2,"0")};
function bldAct(){const xh=k=>`<div class="item col1" id="a_${k}"><div class="inf"><b>${EX[k].n}${k==="sea"?' · корабль ур. <span id="shL"></span>':""}</b><small id="${k}S"></small><div class="bar"><i id="${k}B"></i></div></div><div class="sites">${EX[k].s.map((z,i)=>`<button class="buy" data-a="${k}:${i}"></button>`).join("")}<button class="buy alt" data-a="${k}:claim">Забрать</button>${k==="sea"?'<button class="buy alt" data-a="sea:up" id="shU"></button>':""}</div></div>`;
 $("act").innerHTML=`<h2>Занятия</h2><div class="list"><div class="item col1"><div class="inf"><b>⛏ Золотая шахта · ур. <span id="mL"></span></b><small id="mD"></small><div class="bar"><i id="mB"></i></div></div><div class="sites"><button class="buy" data-a="mine:c" id="mC"></button><button class="buy alt" data-a="mine:u" id="mU"></button></div></div>${xh("hunt")}${xh("sea")}</div>`}
function updAct(){mineTick();const m=s.mine,c=MN.cap(m.l);$("mL").textContent=m.l;$("mD").textContent="Добыча "+fmt(MN.rate(m.l))+"/сек · накоплено "+fmt(m.st)+" / "+fmt(c);$("mB").style.width=m.st/c*100+"%";
 $("mC").disabled=m.st<1;$("mC").textContent="Забрать "+fmt(m.st)+" 🪙";$("mU").disabled=m.l>=MN.max||s.coins<MN.up(m.l);$("mU").textContent=m.l>=MN.max?"МАКС":"Улучшить "+fmt(MN.up(m.l))+" 🪙";
 $("shL").textContent=s.sea.ship;$("shU").disabled=s.sea.ship>=10||s.coins<shipC();$("shU").textContent=s.sea.ship>=10?"Корабль МАКС":"Улучшить корабль "+fmt(shipC())+" 🪙";
 ["hunt","sea"].forEach(k=>{const e=s[k],X=EX[k],run=e.end>0,rdy=run&&Date.now()>=e.end,tm=k==="sea"?shipT():1;
  $(k+"S").textContent=run?(rdy?"Экспедиция вернулась! Заберите награду":X.s[e.i].n+" · осталось "+mmss(e.end-Date.now())):"Выберите место для экспедиции"+(k==="sea"?" (награда ×"+shipM().toFixed(2)+")":"");
  $(k+"B").style.width=run?Math.min(100,100-(e.end-Date.now())/(X.s[e.i].t*1000*tm)*100)+"%":"0%";
  document.querySelectorAll(`[data-a^="${k}:"]`).forEach(b=>{const i=b.dataset.a.split(":")[1];if(i==="claim"){b.disabled=!rdy;b.style.display=run?"":"none"}else if(i!=="up"){const z=X.s[i];b.disabled=run||s.coins<z.c;b.textContent=z.n+" · "+fmt(z.c)+" 🪙 · "+mmss(z.t*1000*tm)+" · до "+fmt(z.r[1]*(k==="sea"?shipM():1)*4)}})})}
$("act").addEventListener("click",e=>{const b=e.target.closest("[data-a]");if(!b)return;const[k,a]=b.dataset.a.split(":");
 if(k==="mine")a==="c"?mineCollect():mineUp();else if(a==="claim")claim(k);else if(a==="up")shipUp();else send(k,+a)});
setInterval(()=>{if(cur==="act")updAct()},1000);


/* ---------- v4.2: скины, инвентарь, рейтинговые очки, загрузка ---------- */
const RAR=[{n:"Обычный",c:"#cfd8dc"},{n:"Редкий",c:"#4fc3f7"},{n:"Эпический",c:"#b57cff"},{n:"Легендарный",c:"#ffb300"}];
const SK=[{id:"forest",n:"Лесной сундук",r:0,p:25000,f:"hue-rotate(80deg) saturate(1.1)",c:"#6bd66b"},
{id:"ocean",n:"Океанский сундук",r:0,p:25000,f:"hue-rotate(170deg) saturate(1.1)",c:"#4fa8ff"},
{id:"crimson",n:"Багровый сундук",r:0,p:30000,f:"hue-rotate(-30deg) saturate(1.6)",c:"#ff5c5c"},
{id:"fire",n:"Огненный сундук",r:1,p:300000,f:"hue-rotate(-25deg) saturate(2.2) brightness(1.05)",c:"#ff5a1f"},
{id:"frost",n:"Ледяной сундук",r:1,p:300000,f:"hue-rotate(180deg) saturate(.7) brightness(1.3)",c:"#9fe3ff"},
{id:"silver",n:"Серебряный сундук",r:1,p:350000,f:"grayscale(1) brightness(1.3) contrast(1.1)",c:"#dfe8f0"},
{id:"amethyst",n:"Аметистовый сундук",r:2,p:4e6,f:"hue-rotate(250deg) saturate(1.5)",c:"#b57cff"},
{id:"emerald",n:"Изумрудный сундук",r:2,p:4e6,f:"hue-rotate(95deg) saturate(1.8) brightness(1.1)",c:"#3dff9a"},
{id:"solar",n:"Солнечный сундук",r:3,p:4e7,f:"saturate(2.2) brightness(1.35)",c:"#fff08a"},
{id:"cosmic",n:"Космический сундук",r:3,p:5e7,f:"hue-rotate(270deg) saturate(2) brightness(1.1)",c:"#ff6bf0"}];
const sk=id=>SK.find(x=>x.id===id);
const ratingPts=()=>Math.floor(s.level*100+s.worlds.length*1000+s.mine.l*150+(s.sea.ship-1)*100+s.titles.length*300+Math.log10(s.total+1)*200);
const skPrev=k=>`<div class="skp" data-r="${k.r}" style="--sf:${k.f};--sk:${k.c}">${rsvg(["#f2b92e","#8a4f20"])}</div>`;
const rb=k=>`<span class="rar" style="background:${RAR[k.r].c}">${RAR[k.r].n}</span>`;
function bldSk(){$("skList").innerHTML=SK.map(k=>`<div class="item">${skPrev(k)}<div class="inf">${rb(k)}<b>${k.n}</b></div><button class="buy" data-sb="${k.id}"></button></div>`).join("")}
let invKey="";
function updSk(){SK.forEach(k=>{const b=document.querySelector(`[data-sb="${k.id}"]`),o=s.skins.own.includes(k.id);b.disabled=o||s.coins<k.p;b.textContent=o?"Куплено ✓":fmt(k.p)+" 🪙"});
 const key=s.skins.own.join()+"|"+s.skins.eq+"|"+s.world;if(key===invKey)return;invKey=key;const e=sk(s.skins.eq);
 $("invNote").textContent=e?"Надет: "+e.n+" — виден во всех мирах":"Надет стандартный сундук мира: "+CN[s.world];
 $("invList").innerHTML=s.skins.own.length?s.skins.own.map(sk).filter(Boolean).map(k=>{const q=s.skins.eq===k.id;return `<div class="item${q?" sel":""}">${skPrev(k)}<div class="inf">${rb(k)}<b>${k.n}</b></div><button class="buy${q?"":" alt"}" ${q?'data-su="1"':`data-se="${k.id}"`}>${q?"Снять":"Надеть"}</button></div>`}).join(""):'<div class="sub">Пока нет скинов. Купите их во вкладке «Скины».</div>'}
function buySk(id){const k=sk(id);if(!k||s.skins.own.includes(id)||s.coins<k.p)return;s.coins-=k.p;s.skins.own.push(id);sfx("buy");toast("Скин куплен: "+k.n);save();hud()}
function equip(id){if(!s.skins.own.includes(id))return;s.skins.eq=id;chestLook();sfx("ui");save();hud()}
function unequip(){s.skins.eq="";chestLook();sfx("ui");save();hud()}
$("skList").addEventListener("click",e=>{const b=e.target.closest("[data-sb]");b&&buySk(b.dataset.sb)});
$("invList").addEventListener("click",e=>{const b=e.target.closest("[data-se],[data-su]");if(b)b.dataset.se?equip(b.dataset.se):unequip()});
document.querySelector(".seg").addEventListener("click",e=>{const b=e.target.closest("[data-sh]");if(!b)return;document.querySelectorAll(".seg button").forEach(x=>x.classList.toggle("on",x===b));
 [["up","shUp"],["sk","shSk"],["inv","shInv"]].forEach(([k,id])=>$(id).hidden=k!==b.dataset.sh);invKey="";sfx("ui");hud()});
/* экран загрузки: прогресс = реально загруженные файлы */
function boot(){const B=$("boot"),bar=$("bootBar"),tx=$("bootTxt"),rt=$("bootRetry");
 const files=[...WD.map(w=>"assets/world-"+w.id+".svg"),"assets/icon.svg","assets/icon-192.png"],total=files.length+1;let done=0,ready=false,splash=false;
 const fin=()=>{if(ready&&splash)setTimeout(()=>{B.classList.add("off");setTimeout(()=>B.remove(),600)},250)};
 const load=u=>new Promise((ok,no)=>{const i=new Image();i.onload=ok;i.onerror=()=>no(u);i.src=u});
 const set=t=>{bar.style.width=Math.min(100,done/total*100)+"%";if(t)tx.textContent=t};
 async function run(){done=0;ready=false;rt.hidden=true;set("Подготовка игровых ресурсов…");
  try{for(const f of files){await load(f);done++;set()}
   set("Загрузка прогресса…");JSON.stringify(s);if(!s||typeof s.coins!=="number")throw"save";done++;set("Готово");ready=true;fin()}
  catch(e){B.className="p2";tx.textContent="Не удалось загрузить игру ("+e+"). Проверьте подключение.";rt.hidden=false}}
 B.className="p1";setTimeout(()=>{splash=true;if(B.isConnected&&rt.hidden)B.className="p2";fin()},1200);rt.onclick=run;run()}

setInterval(save,5000);
if("serviceWorker"in navigator)addEventListener("load",()=>navigator.serviceWorker.register("sw.js").catch(()=>{}));
build();bldCU();bldSk();bldAct();ensureDay();$("nick").value=s.nick;setWorld(true);sw();
const off=Math.min((Date.now()-(s.ts||Date.now()))/1000,3600)*auto()*.5;if(off>=1){gain(off,0);toast("Пока вас не было: +"+fmt(off)+" 🪙")}
hud();save();boot();
})();
